'use strict';



;define("star-wars/adapters/application", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _emberData.default.RESTAdapter.extend({
    host: 'https://swapi.co',
    namespace: '/api'
  });

  _exports.default = _default;
});
;define("star-wars/adapters/drf", ["exports", "ember-django-adapter/adapters/drf", "star-wars/config/environment"], function (_exports, _drf, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _drf.default.extend({
    host: Ember.computed(function () {
      return _environment.default.APP.API_HOST;
    }),
    namespace: Ember.computed(function () {
      return _environment.default.APP.API_NAMESPACE;
    })
  });

  _exports.default = _default;
});
;define("star-wars/app", ["exports", "star-wars/resolver", "ember-load-initializers", "star-wars/config/environment"], function (_exports, _resolver, _emberLoadInitializers, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const App = Ember.Application.extend({
    modulePrefix: _environment.default.modulePrefix,
    podModulePrefix: _environment.default.podModulePrefix,
    Resolver: _resolver.default
  });
  (0, _emberLoadInitializers.default)(App, _environment.default.modulePrefix);
  var _default = App;
  _exports.default = _default;
});
;define("star-wars/components/card", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Component.extend({});

  _exports.default = _default;
});
;define("star-wars/components/cards", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const STARSHIP_MAX = 37;
  const PEOPLE_MAX = 87;

  function getRandomNumber(min, max) {
    let rand = min + Math.random() * (max + 1 - min);
    return Math.floor(rand);
  }

  function getNewCards(isTypePerson, gameData) {
    const max = isTypePerson ? STARSHIP_MAX : PEOPLE_MAX;
    return gameData.getCardsData(getRandomNumber(1, max), getRandomNumber(1, max), isTypePerson);
  }

  function setWinner(cardOneData, cardTwoData, isTypePerson) {
    const prop = isTypePerson ? 'mass' : 'crew';
    const isDraw = cardOneData[prop] === cardTwoData[prop];
    if (isDraw) return null;
    const winner = cardOneData[prop] > cardTwoData[prop] ? cardOneData : cardTwoData;
    return winner['isWinner'] = true;
  }

  var _default = Ember.Component.extend({
    gameData: Ember.inject.service('gameData'),
    isPerson: true,
    cardOneData: null,
    cardTwoData: null,
    actions: {
      async getCards() {
        const {
          cardOneData,
          cardTwoData
        } = await getNewCards(this.isPerson, this.gameData);
        setWinner(cardOneData, cardTwoData, this.isPerson);
        this.setProperties({
          cardOneData,
          cardTwoData
        });
      },

      toggleType(isTypePerson) {
        this.set('isPerson', isTypePerson);
      }

    }
  });

  _exports.default = _default;
});
;define("star-wars/components/welcome-page", ["exports", "ember-welcome-page/components/welcome-page"], function (_exports, _welcomePage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _welcomePage.default;
    }
  });
});
;define("star-wars/helpers/app-version", ["exports", "star-wars/config/environment", "ember-cli-app-version/utils/regexp"], function (_exports, _environment, _regexp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.appVersion = appVersion;
  _exports.default = void 0;

  function appVersion(_, hash = {}) {
    const version = _environment.default.APP.version; // e.g. 1.0.0-alpha.1+4jds75hf
    // Allow use of 'hideSha' and 'hideVersion' For backwards compatibility

    let versionOnly = hash.versionOnly || hash.hideSha;
    let shaOnly = hash.shaOnly || hash.hideVersion;
    let match = null;

    if (versionOnly) {
      if (hash.showExtended) {
        match = version.match(_regexp.versionExtendedRegExp); // 1.0.0-alpha.1
      } // Fallback to just version


      if (!match) {
        match = version.match(_regexp.versionRegExp); // 1.0.0
      }
    }

    if (shaOnly) {
      match = version.match(_regexp.shaRegExp); // 4jds75hf
    }

    return match ? match[0] : version;
  }

  var _default = Ember.Helper.helper(appVersion);

  _exports.default = _default;
});
;define("star-wars/helpers/pluralize", ["exports", "ember-inflector/lib/helpers/pluralize"], function (_exports, _pluralize) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _pluralize.default;
  _exports.default = _default;
});
;define("star-wars/helpers/singularize", ["exports", "ember-inflector/lib/helpers/singularize"], function (_exports, _singularize) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _singularize.default;
  _exports.default = _default;
});
;define("star-wars/initializers/app-version", ["exports", "ember-cli-app-version/initializer-factory", "star-wars/config/environment"], function (_exports, _initializerFactory, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  let name, version;

  if (_environment.default.APP) {
    name = _environment.default.APP.name;
    version = _environment.default.APP.version;
  }

  var _default = {
    name: 'App Version',
    initialize: (0, _initializerFactory.default)(name, version)
  };
  _exports.default = _default;
});
;define("star-wars/initializers/container-debug-adapter", ["exports", "ember-resolver/resolvers/classic/container-debug-adapter"], function (_exports, _containerDebugAdapter) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'container-debug-adapter',

    initialize() {
      let app = arguments[1] || arguments[0];
      app.register('container-debug-adapter:main', _containerDebugAdapter.default);
      app.inject('container-debug-adapter:main', 'namespace', 'application:main');
    }

  };
  _exports.default = _default;
});
;define("star-wars/initializers/custom-inflector-rules", ["exports", "ember-inflector"], function (_exports, _emberInflector) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.initialize = initialize;
  _exports.default = void 0;

  function initialize() {
    const inflector = _emberInflector.default.inflector;
    inflector.uncountable('people');
  }

  var _default = {
    name: 'custom-inflector-rules',
    initialize
  };
  _exports.default = _default;
});
;define("star-wars/initializers/ember-data", ["exports", "ember-data/setup-container", "ember-data"], function (_exports, _setupContainer, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  /*
  
    This code initializes Ember-Data onto an Ember application.
  
    If an Ember.js developer defines a subclass of DS.Store on their application,
    as `App.StoreService` (or via a module system that resolves to `service:store`)
    this code will automatically instantiate it and make it available on the
    router.
  
    Additionally, after an application's controllers have been injected, they will
    each have the store made available to them.
  
    For example, imagine an Ember.js application with the following classes:
  
    ```app/services/store.js
    import DS from 'ember-data';
  
    export default DS.Store.extend({
      adapter: 'custom'
    });
    ```
  
    ```app/controllers/posts.js
    import { Controller } from '@ember/controller';
  
    export default Controller.extend({
      // ...
    });
  
    When the application is initialized, `ApplicationStore` will automatically be
    instantiated, and the instance of `PostsController` will have its `store`
    property set to that instance.
  
    Note that this code will only be run if the `ember-application` package is
    loaded. If Ember Data is being used in an environment other than a
    typical application (e.g., node.js where only `ember-runtime` is available),
    this code will be ignored.
  */
  var _default = {
    name: 'ember-data',
    initialize: _setupContainer.default
  };
  _exports.default = _default;
});
;define("star-wars/initializers/export-application-global", ["exports", "star-wars/config/environment"], function (_exports, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.initialize = initialize;
  _exports.default = void 0;

  function initialize() {
    var application = arguments[1] || arguments[0];

    if (_environment.default.exportApplicationGlobal !== false) {
      var theGlobal;

      if (typeof window !== 'undefined') {
        theGlobal = window;
      } else if (typeof global !== 'undefined') {
        theGlobal = global;
      } else if (typeof self !== 'undefined') {
        theGlobal = self;
      } else {
        // no reasonable global, just bail
        return;
      }

      var value = _environment.default.exportApplicationGlobal;
      var globalName;

      if (typeof value === 'string') {
        globalName = value;
      } else {
        globalName = Ember.String.classify(_environment.default.modulePrefix);
      }

      if (!theGlobal[globalName]) {
        theGlobal[globalName] = application;
        application.reopen({
          willDestroy: function () {
            this._super.apply(this, arguments);

            delete theGlobal[globalName];
          }
        });
      }
    }
  }

  var _default = {
    name: 'export-application-global',
    initialize: initialize
  };
  _exports.default = _default;
});
;define("star-wars/instance-initializers/ember-data", ["exports", "ember-data/initialize-store-service"], function (_exports, _initializeStoreService) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'ember-data',
    initialize: _initializeStoreService.default
  };
  _exports.default = _default;
});
;define("star-wars/models/people", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const {
    Model
  } = _emberData.default;

  var _default = Model.extend({
    name: _emberData.default.attr('string'),
    height: _emberData.default.attr('string'),
    gender: _emberData.default.attr('string'),
    mass: _emberData.default.attr('string')
  });

  _exports.default = _default;
});
;define("star-wars/models/star-wars", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const {
    Model
  } = _emberData.default;

  var _default = Model.extend({
    title: _emberData.default.attr(),
    crew: _emberData.default.attr(),
    mass: _emberData.default.attr()
  });

  _exports.default = _default;
});
;define("star-wars/models/starship", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const {
    Model
  } = _emberData.default;

  var _default = Model.extend({
    name: _emberData.default.attr('string'),
    model: _emberData.default.attr('string'),
    manufacturer: _emberData.default.attr('string'),
    crew: _emberData.default.attr('string')
  });

  _exports.default = _default;
});
;define("star-wars/resolver", ["exports", "ember-resolver"], function (_exports, _emberResolver) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _emberResolver.default;
  _exports.default = _default;
});
;define("star-wars/router", ["exports", "star-wars/config/environment"], function (_exports, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const Router = Ember.Router.extend({
    location: _environment.default.locationType,
    rootURL: _environment.default.rootURL
  });
  Router.map(function () {});
  var _default = Router;
  _exports.default = _default;
});
;define("star-wars/routes/index", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({});

  _exports.default = _default;
});
;define("star-wars/serializers/application", ["exports", "star-wars/serializers/drf"], function (_exports, _drf) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _drf.default;
  _exports.default = _default;
});
;define("star-wars/serializers/drf", ["exports", "ember-django-adapter/serializers/drf"], function (_exports, _drf) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _drf.default;
  _exports.default = _default;
});
;define("star-wars/serializers/people", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _emberData.default.RESTSerializer.extend({
    normalizeFindRecordResponse(store, primaryModelClass, payload, id, requestType) {
      const data = {
        people: {
          id,
          name: payload.name,
          gender: payload.gender,
          height: payload.height,
          mass: payload.mass === 'unknown' ? 0 : payload.mass
        }
      };
      return this._super(store, primaryModelClass, data, id, requestType);
    }

  });

  _exports.default = _default;
});
;define("star-wars/serializers/starship", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _emberData.default.RESTSerializer.extend({
    normalizeFindRecordResponse(store, primaryModelClass, payload, id, requestType) {
      const data = {
        starships: {
          id,
          name: payload.name,
          manufacturer: payload.manufacturer,
          model: payload.model,
          crew: payload.crew === 'unknown' ? 0 : payload.crew
        }
      };
      return this._super(store, primaryModelClass, data, id, requestType);
    }

  });

  _exports.default = _default;
});
;define("star-wars/services/ajax", ["exports", "ember-ajax/services/ajax"], function (_exports, _ajax) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _ajax.default;
    }
  });
});
;define("star-wars/services/game-data", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Service.extend({
    store: Ember.inject.service(),

    async getCardsData(firstId, secondId, isPersonType) {
      try {
        const cardOneData = await this.store.findRecord(isPersonType ? 'people' : 'starship', firstId);
        const cardTwoData = await this.store.findRecord(isPersonType ? 'people' : 'starship', secondId);
        return {
          cardOneData,
          cardTwoData
        };
      } catch (e) {
        alert('Seems it something went wrong. Try again');
      }
    }

  });

  _exports.default = _default;
});
;define("star-wars/templates/application", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "/ducRBqm",
    "block": "{\"symbols\":[],\"statements\":[[7,\"main\",true],[10,\"class\",\"text-center p-3\"],[8],[0,\"\\n  \"],[1,[22,\"outlet\"],false],[0,\"\\n\"],[9]],\"hasEval\":false}",
    "meta": {
      "moduleName": "star-wars/templates/application.hbs"
    }
  });

  _exports.default = _default;
});
;define("star-wars/templates/components/card", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "RnvEi2nw",
    "block": "{\"symbols\":[\"@cardData\"],\"statements\":[[7,\"div\",true],[10,\"class\",\"card m-2\"],[8],[0,\"\\n  \"],[7,\"h5\",true],[10,\"class\",\"card-title mt-3\"],[8],[0,\"\\n    \"],[4,\"if\",[[23,1,[\"name\"]]],null,{\"statements\":[[1,[23,1,[\"name\"]],false]],\"parameters\":[]},{\"statements\":[[0,\"Press Play button\"]],\"parameters\":[]}],[0,\"\\n    \"],[4,\"if\",[[24,[\"cardData\",\"isWinner\"]]],null,{\"statements\":[[7,\"span\",true],[10,\"class\",\"badge badge-danger\"],[8],[0,\"Winner\"],[9]],\"parameters\":[]},null],[0,\"\\n  \"],[9],[0,\"\\n  \"],[7,\"ul\",true],[10,\"class\",\"list-group list-group-flush text-left\"],[8],[0,\"\\n\"],[4,\"if\",[[24,[\"cardData\",\"mass\"]]],null,{\"statements\":[[0,\"      \"],[7,\"li\",true],[10,\"class\",\"list-group-item\"],[8],[0,\"Mass: \"],[1,[24,[\"cardData\",\"mass\"]],false],[9],[0,\"\\n\"]],\"parameters\":[]},null],[4,\"if\",[[24,[\"cardData\",\"gender\"]]],null,{\"statements\":[[0,\"      \"],[7,\"li\",true],[10,\"class\",\"list-group-item\"],[8],[0,\"Gender: \"],[1,[24,[\"cardData\",\"gender\"]],false],[9],[0,\"\\n\"]],\"parameters\":[]},null],[4,\"if\",[[24,[\"cardData\",\"height\"]]],null,{\"statements\":[[0,\"      \"],[7,\"li\",true],[10,\"class\",\"list-group-item\"],[8],[0,\"Height: \"],[1,[24,[\"cardData\",\"height\"]],false],[9],[0,\"\\n\"]],\"parameters\":[]},null],[4,\"if\",[[24,[\"cardData\",\"model\"]]],null,{\"statements\":[[0,\"      \"],[7,\"li\",true],[10,\"class\",\"list-group-item\"],[8],[0,\"Model: \"],[1,[24,[\"cardData\",\"model\"]],false],[9],[0,\"\\n\"]],\"parameters\":[]},null],[4,\"if\",[[24,[\"cardData\",\"manufacturer\"]]],null,{\"statements\":[[0,\"      \"],[7,\"li\",true],[10,\"class\",\"list-group-item\"],[8],[0,\"Manufacturer: \"],[1,[24,[\"cardData\",\"manufacturer\"]],false],[9],[0,\"\\n\"]],\"parameters\":[]},null],[4,\"if\",[[24,[\"cardData\",\"crew\"]]],null,{\"statements\":[[0,\"      \"],[7,\"li\",true],[10,\"class\",\"list-group-item\"],[8],[0,\"Crew: \"],[1,[24,[\"cardData\",\"crew\"]],false],[9],[0,\"\\n\"]],\"parameters\":[]},null],[0,\"  \"],[9],[0,\"\\n\"],[9],[0,\"\\n\"]],\"hasEval\":false}",
    "meta": {
      "moduleName": "star-wars/templates/components/card.hbs"
    }
  });

  _exports.default = _default;
});
;define("star-wars/templates/components/cards", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "ReyNYwVA",
    "block": "{\"symbols\":[\"&default\"],\"statements\":[[7,\"div\",true],[8],[0,\"Chose competitors:\"],[9],[0,\"\\n\"],[7,\"div\",true],[10,\"class\",\"btn-group btn-group-toggle\"],[10,\"data-toggle\",\"buttons\"],[8],[0,\"\\n  \"],[7,\"label\",true],[11,\"class\",[29,[\"btn btn-secondary \",[28,\"if\",[[23,0,[\"isPerson\"]],\"\",\"active\"],null]]]],[8],[0,\"\\n    \"],[7,\"input\",false],[12,\"name\",\"options\"],[12,\"id\",\"starships\"],[12,\"autocomplete\",\"off\"],[12,\"type\",\"radio\"],[3,\"action\",[[23,0,[]],\"toggleType\",false]],[8],[9],[0,\" Starships\\n  \"],[9],[0,\"\\n  \"],[7,\"label\",true],[11,\"class\",[29,[\"btn btn-secondary \",[28,\"if\",[[23,0,[\"isPerson\"]],\"active\",\"\"],null]]]],[8],[0,\"\\n    \"],[7,\"input\",false],[12,\"name\",\"options\"],[12,\"id\",\"persons\"],[12,\"autocomplete\",\"off\"],[12,\"type\",\"radio\"],[3,\"action\",[[23,0,[]],\"toggleType\",true]],[8],[9],[0,\" Persons\\n  \"],[9],[0,\"\\n\"],[9],[0,\"\\n\\n\"],[7,\"div\",true],[10,\"class\",\"card-deck align-items-center justify-content-center m-2\"],[8],[0,\"\\n  \"],[7,\"div\",true],[10,\"class\",\"card-deck align-items-center justify-content-center m-2\"],[8],[0,\"\\n    \"],[5,\"card\",[],[[\"@cardData\",\"@type\"],[[23,0,[\"cardOneData\"]],[23,0,[\"isPerson\"]]]]],[0,\"\\n    \"],[7,\"span\",true],[8],[0,\"VS\"],[9],[0,\"\\n    \"],[5,\"card\",[],[[\"@cardData\",\"@type\"],[[23,0,[\"cardTwoData\"]],[23,0,[\"isPerson\"]]]]],[0,\"\\n  \"],[9],[0,\"\\n\"],[9],[0,\"\\n\\n\"],[7,\"button\",false],[12,\"class\",\"btn btn-primary\"],[3,\"action\",[[23,0,[]],\"getCards\",[23,0,[\"isPerson\"]]]],[8],[0,\"Play\"],[9],[0,\"\\n\\n\"],[14,1]],\"hasEval\":false}",
    "meta": {
      "moduleName": "star-wars/templates/components/cards.hbs"
    }
  });

  _exports.default = _default;
});
;define("star-wars/templates/index", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "A3pnqBqc",
    "block": "{\"symbols\":[],\"statements\":[[7,\"h1\",true],[8],[0,\"Star Wars Awesome Game\"],[9],[0,\"\\n\\n\"],[5,\"cards\",[],[[],[]]],[0,\"\\n\\n\"],[1,[22,\"outlet\"],false]],\"hasEval\":false}",
    "meta": {
      "moduleName": "star-wars/templates/index.hbs"
    }
  });

  _exports.default = _default;
});
;

;define('star-wars/config/environment', [], function() {
  var prefix = 'star-wars';
try {
  var metaName = prefix + '/config/environment';
  var rawConfig = document.querySelector('meta[name="' + metaName + '"]').getAttribute('content');
  var config = JSON.parse(decodeURIComponent(rawConfig));

  var exports = { 'default': config };

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

});

;
          if (!runningTests) {
            require("star-wars/app")["default"].create({"host":"https://swapi.co","LOG_ACTIVE_GENERATION":false,"LOG_VIEW_LOOKUPS":false,"rootElement":"#ember-testing","autoboot":false,"name":"star-wars","version":"0.0.0+c12b76bd","API_HOST":"http://localhost:8000","API_NAMESPACE":"api","API_ADD_TRAILING_SLASHES":true});
          }
        
//# sourceMappingURL=star-wars.map
