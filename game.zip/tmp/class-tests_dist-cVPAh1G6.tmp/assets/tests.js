'use strict';

define("star-wars/tests/acceptance/star-wars-test", ["qunit", "@ember/test-helpers", "ember-qunit"], function (_qunit, _testHelpers, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Acceptance | star wars', function (hooks) {
    (0, _emberQunit.setupApplicationTest)(hooks);
    (0, _qunit.test)('should show heading home page', async function (assert) {
      await (0, _testHelpers.visit)('/');
      assert.equal(this.element.querySelectorAll('h1').length, 1, 'should display heading');
    });
    (0, _qunit.test)('should show 2 cards', async function (assert) {
      await (0, _testHelpers.visit)('/');
      assert.equal(this.element.querySelectorAll('.card').length, 2, 'should display 2 cards');
    });
    (0, _qunit.test)('should show play button', async function (assert) {
      await (0, _testHelpers.visit)('/');
      assert.equal(this.element.querySelectorAll('.btn-primary').length, 1, 'should display play button');
    });
  });
});
define("star-wars/tests/integration/components/card-test", ["qunit", "ember-qunit", "@ember/test-helpers"], function (_qunit, _emberQunit, _testHelpers) {
  "use strict";

  (0, _qunit.module)('Integration | Component | card', function (hooks) {
    (0, _emberQunit.setupRenderingTest)(hooks);
    (0, _qunit.test)('it renders', async function (assert) {
      await (0, _testHelpers.render)(Ember.HTMLBars.template({
        "id": "YP6FwMBv",
        "block": "{\"symbols\":[],\"statements\":[[5,\"card\",[],[[],[]]]],\"hasEval\":false}",
        "meta": {}
      }));
      assert.equal(this.element.textContent.trim(), 'Press Play button');
      await (0, _testHelpers.render)(Ember.HTMLBars.template({
        "id": "zDFA95Nx",
        "block": "{\"symbols\":[],\"statements\":[[0,\"\\n      \"],[5,\"card\",[],[[],[]]],[0,\"\\n    \"]],\"hasEval\":false}",
        "meta": {}
      }));
      assert.equal(this.element.textContent.trim(), 'Press Play button');
    });
  });
});
define("star-wars/tests/integration/components/cards-test", ["qunit", "ember-qunit", "@ember/test-helpers"], function (_qunit, _emberQunit, _testHelpers) {
  "use strict";

  (0, _qunit.module)('Integration | Component | cards', function (hooks) {
    (0, _emberQunit.setupRenderingTest)(hooks);
    (0, _qunit.test)('it renders 2 cards', async function (assert) {
      await (0, _testHelpers.render)(Ember.HTMLBars.template({
        "id": "n5aFajyc",
        "block": "{\"symbols\":[],\"statements\":[[5,\"cards\",[],[[],[]]]],\"hasEval\":false}",
        "meta": {}
      }));
      assert.equal(this.element.querySelectorAll('.card').length, 2, 'should display 2 cards');
    });
  });
});
define("star-wars/tests/lint/app.lint-test", [], function () {
  "use strict";

  QUnit.module('ESLint | app');
  QUnit.test('adapters/application.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'adapters/application.js should pass ESLint\n\n');
  });
  QUnit.test('app.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'app.js should pass ESLint\n\n');
  });
  QUnit.test('components/card.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/card.js should pass ESLint\n\n');
  });
  QUnit.test('components/cards.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/cards.js should pass ESLint\n\n');
  });
  QUnit.test('initializers/custom-inflector-rules.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/custom-inflector-rules.js should pass ESLint\n\n');
  });
  QUnit.test('models/people.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/people.js should pass ESLint\n\n');
  });
  QUnit.test('models/star-wars.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/star-wars.js should pass ESLint\n\n');
  });
  QUnit.test('models/starship.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/starship.js should pass ESLint\n\n');
  });
  QUnit.test('resolver.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'resolver.js should pass ESLint\n\n');
  });
  QUnit.test('router.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'router.js should pass ESLint\n\n');
  });
  QUnit.test('routes/index.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/index.js should pass ESLint\n\n');
  });
  QUnit.test('serializers/people.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'serializers/people.js should pass ESLint\n\n');
  });
  QUnit.test('serializers/starship.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'serializers/starship.js should pass ESLint\n\n');
  });
  QUnit.test('services/game-data.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/game-data.js should pass ESLint\n\n');
  });
});
define("star-wars/tests/lint/templates.template.lint-test", [], function () {
  "use strict";

  QUnit.module('TemplateLint');
  QUnit.test('star-wars/templates/application.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'star-wars/templates/application.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('star-wars/templates/components/card.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'star-wars/templates/components/card.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('star-wars/templates/components/cards.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'star-wars/templates/components/cards.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('star-wars/templates/index.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'star-wars/templates/index.hbs should pass TemplateLint.\n\n');
  });
});
define("star-wars/tests/lint/tests.lint-test", [], function () {
  "use strict";

  QUnit.module('ESLint | tests');
  QUnit.test('acceptance/star-wars-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'acceptance/star-wars-test.js should pass ESLint\n\n');
  });
  QUnit.test('integration/components/card-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/card-test.js should pass ESLint\n\n');
  });
  QUnit.test('integration/components/cards-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/cards-test.js should pass ESLint\n\n');
  });
  QUnit.test('test-helper.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'test-helper.js should pass ESLint\n\n');
  });
  QUnit.test('unit/adapters/application-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/adapters/application-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/initializers/custom-inflector-rules-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/initializers/custom-inflector-rules-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/models/people-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/people-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/models/starship-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/starship-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/index-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/index-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/serializers/people-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/serializers/people-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/serializers/starships-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/serializers/starships-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/services/game-data-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/services/game-data-test.js should pass ESLint\n\n');
  });
});
define("star-wars/tests/test-helper", ["star-wars/app", "star-wars/config/environment", "@ember/test-helpers", "ember-qunit"], function (_app, _environment, _testHelpers, _emberQunit) {
  "use strict";

  (0, _testHelpers.setApplication)(_app.default.create(_environment.default.APP));
  (0, _emberQunit.start)();
});
define("star-wars/tests/unit/adapters/application-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Adapter | application', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let adapter = this.owner.lookup('adapter:application');
      assert.ok(adapter);
    });
  });
});
define("star-wars/tests/unit/initializers/custom-inflector-rules-test", ["star-wars/initializers/custom-inflector-rules", "qunit"], function (_customInflectorRules, _qunit) {
  "use strict";

  (0, _qunit.module)('Unit | Initializer | custom-inflector-rules', function (hooks) {
    hooks.beforeEach(function () {
      this.TestApplication = Ember.Application.extend();
      this.TestApplication.initializer({
        name: 'initializer under test',
        initialize: _customInflectorRules.initialize
      });
      this.application = this.TestApplication.create({
        autoboot: false
      });
    });
    hooks.afterEach(function () {
      Ember.run(this.application, 'destroy');
    });
    (0, _qunit.test)('it works', async function (assert) {
      await this.application.boot();
      assert.ok(true);
    });
  });
});
define("star-wars/tests/unit/models/people-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Model | people', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let store = this.owner.lookup('service:store');
      let model = store.createRecord('people', {});
      assert.ok(model);
    });
  });
});
define("star-wars/tests/unit/models/starship-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Model | starship', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let store = this.owner.lookup('service:store');
      let model = store.createRecord('starship', {});
      assert.ok(model);
    });
  });
});
define("star-wars/tests/unit/routes/index-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | index', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:index');
      assert.ok(route);
    });
  });
});
define("star-wars/tests/unit/serializers/people-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Serializer | people', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let store = this.owner.lookup('service:store');
      let serializer = store.serializerFor('people');
      assert.ok(serializer);
    });
    (0, _qunit.test)('it serializes records', function (assert) {
      let store = this.owner.lookup('service:store');
      let record = store.createRecord('people', {});
      let serializedRecord = record.serialize();
      assert.ok(serializedRecord);
    });
  });
});
define("star-wars/tests/unit/serializers/starships-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Serializer | starship', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let store = this.owner.lookup('service:store');
      let serializer = store.serializerFor('starship');
      assert.ok(serializer);
    });
    (0, _qunit.test)('it serializes records', function (assert) {
      let store = this.owner.lookup('service:store');
      let record = store.createRecord('starship', {});
      let serializedRecord = record.serialize();
      assert.ok(serializedRecord);
    });
  });
});
define("star-wars/tests/unit/services/game-data-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Service | game-data', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let service = this.owner.lookup('service:game-data');
      assert.ok(service);
    });
  });
});
define('star-wars/config/environment', [], function() {
  var prefix = 'star-wars';
try {
  var metaName = prefix + '/config/environment';
  var rawConfig = document.querySelector('meta[name="' + metaName + '"]').getAttribute('content');
  var config = JSON.parse(decodeURIComponent(rawConfig));

  var exports = { 'default': config };

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

});

require('star-wars/tests/test-helper');
EmberENV.TESTS_FILE_LOADED = true;
//# sourceMappingURL=tests.map
